"""Inventory service package."""
