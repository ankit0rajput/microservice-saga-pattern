"""Inventory service application package."""
